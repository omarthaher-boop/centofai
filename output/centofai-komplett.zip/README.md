# Centofai – Anleitung

  ## Inhalt dieses ZIPs

  - `dist-zum-hochladen/`  → Diesen Ordnerinhalt per FTP in den Web-Root deines Infomaniak-Hostings hochladen (meist `web/` oder `sites/deinedomain/`).
  - `quellcode/`            → Der React-Quellcode, falls du später Änderungen machen willst.

  ## Upload auf Infomaniak (FTP)

  1. Logge dich im Infomaniak-Manager ein und öffne dein Web-Hosting.
  2. Öffne FTP (z.B. mit FileZilla) – die Zugangsdaten findest du im Manager unter "FTP / SSH".
  3. Wechsle in den Web-Root-Ordner (meist `web/` oder `sites/deinedomain.tld/`).
  4. Lösche dort vorhandene Demo-Dateien (z.B. `index.html` von Infomaniak).
  5. Lade den **kompletten Inhalt** des Ordners `dist-zum-hochladen/` hoch (NICHT den Ordner selbst, sondern alle Dateien darin: `index.html`, `assets/`, `.htaccess`).
  6. Domain im Browser öffnen – fertig.

  ## Quellcode bearbeiten

  ```bash
  cd quellcode
  npm install
  npm run dev        # lokale Vorschau auf http://localhost:5173
  npm run build      # neuen dist-Ordner erstellen
  ```
  Nach dem Build den Inhalt des neuen `dist/` Ordners wieder hochladen.
  